-- CentreCare initial schema
-- Long day care centres: compliance tracking + educator memos -> AI logs -> parent updates.

-- gen_random_uuid() is built into Postgres 13+, no extension needed.

-- ---------------------------------------------------------------------------
-- Types
-- ---------------------------------------------------------------------------
create type public.user_role as enum ('director', 'educator', 'parent');
create type public.requirement_subject as enum ('staff', 'child', 'centre');
create type public.log_status as enum ('draft', 'approved');
create type public.log_category as enum (
  'meal', 'sleep', 'nappy', 'learning', 'wellbeing', 'incident', 'health', 'other'
);

-- ---------------------------------------------------------------------------
-- Tables
-- ---------------------------------------------------------------------------
create table public.centres (
  id           uuid primary key default gen_random_uuid(),
  name         text not null,
  staff_code   text not null unique default upper(substr(md5(random()::text), 1, 6)),
  family_code  text not null unique default upper(substr(md5(random()::text), 1, 6)),
  created_at   timestamptz not null default now()
);

create table public.profiles (
  id          uuid primary key references auth.users (id) on delete cascade,
  email       text not null,
  full_name   text not null default '',
  centre_id   uuid references public.centres (id) on delete set null,
  role        public.user_role,
  created_at  timestamptz not null default now()
);
create index on public.profiles (centre_id);
create index on public.profiles (lower(email));

create table public.rooms (
  id          uuid primary key default gen_random_uuid(),
  centre_id   uuid not null references public.centres (id) on delete cascade,
  name        text not null,
  age_group   text not null default '',
  created_at  timestamptz not null default now()
);
create index on public.rooms (centre_id);

create table public.children (
  id             uuid primary key default gen_random_uuid(),
  centre_id      uuid not null references public.centres (id) on delete cascade,
  room_id        uuid references public.rooms (id) on delete set null,
  first_name     text not null,
  last_name      text not null default '',
  date_of_birth  date,
  alerts         text[] not null default '{}',   -- allergies, medical plans, dietary
  home_language  text not null default 'English',
  photo_consent  boolean not null default false,
  created_at     timestamptz not null default now()
);
create index on public.children (centre_id);
create index on public.children (room_id);

create table public.guardians (
  child_id    uuid not null references public.children (id) on delete cascade,
  profile_id  uuid not null references public.profiles (id) on delete cascade,
  relationship text not null default 'Parent',
  primary key (child_id, profile_id)
);
create index on public.guardians (profile_id);

-- Anything that can expire or needs follow-up: first aid, WWCC, action plans,
-- EpiPens, fire drills, policy reviews...
create table public.requirements (
  id            uuid primary key default gen_random_uuid(),
  centre_id     uuid not null references public.centres (id) on delete cascade,
  subject_type  public.requirement_subject not null,
  staff_id      uuid references public.profiles (id) on delete cascade,
  staff_name    text,               -- for staff not yet on the app
  child_id      uuid references public.children (id) on delete cascade,
  kind          text not null,      -- e.g. 'First aid (HLTAID012)'
  expires_on    date,               -- null = no expiry, needs one-off follow-up
  completed_at  timestamptz,        -- for one-off tasks
  notes         text not null default '',
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  constraint subject_matches check (
    (subject_type = 'child'  and child_id is not null) or
    (subject_type = 'staff'  and (staff_id is not null or staff_name is not null)) or
    (subject_type = 'centre')
  )
);
create index on public.requirements (centre_id, expires_on);

-- Status is derived, never stored, so it can't go stale.
create view public.requirement_status
with (security_invoker = true) as
select
  r.*,
  case
    when r.expires_on is null and r.completed_at is not null then 'ok'
    when r.expires_on is null then 'due_soon'
    when r.expires_on < current_date then 'overdue'
    when r.expires_on <= current_date + 30 then 'due_soon'
    else 'ok'
  end as status,
  case
    when r.subject_type = 'child' then trim(c.first_name || ' ' || c.last_name)
    when r.subject_type = 'staff' then coalesce(nullif(p.full_name, ''), r.staff_name, p.email)
    else 'Centre'
  end as subject_name
from public.requirements r
left join public.children c on c.id = r.child_id
left join public.profiles p on p.id = r.staff_id;

-- Educator memo, after the educator has checked the transcript.
create table public.memos (
  id           uuid primary key default gen_random_uuid(),
  centre_id    uuid not null references public.centres (id) on delete cascade,
  child_id     uuid not null references public.children (id) on delete cascade,
  educator_id  uuid not null references public.profiles (id) on delete cascade,
  transcript   text not null,
  created_at   timestamptz not null default now()
);
create index on public.memos (child_id, created_at desc);

-- AI-drafted, educator-approved log. Parents only ever see approved logs.
create table public.logs (
  id           uuid primary key default gen_random_uuid(),
  centre_id    uuid not null references public.centres (id) on delete cascade,
  child_id     uuid not null references public.children (id) on delete cascade,
  memo_id      uuid references public.memos (id) on delete set null,
  author_id    uuid not null references public.profiles (id) on delete cascade,
  category     public.log_category not null default 'other',
  title        text not null,
  parent_note  text not null,
  details      jsonb not null default '[]',   -- [{label, value}]
  eylf_outcome text,
  flags        text[] not null default '{}',   -- staff follow-ups, e.g. incident report
  ai_drafted   boolean not null default true,
  status       public.log_status not null default 'draft',
  approved_by  uuid references public.profiles (id),
  approver_name text,                          -- shown to parents ("reviewed by ...")
  approved_at  timestamptz,
  created_at   timestamptz not null default now()
);
create index on public.logs (child_id, created_at desc);
create index on public.logs (centre_id, status);

-- ---------------------------------------------------------------------------
-- Helpers (security definer so RLS policies can call them without recursion)
-- ---------------------------------------------------------------------------
create or replace function public.my_centre_id() returns uuid
language sql stable security definer set search_path = public as $$
  select centre_id from public.profiles where id = auth.uid()
$$;

create or replace function public.my_role() returns public.user_role
language sql stable security definer set search_path = public as $$
  select role from public.profiles where id = auth.uid()
$$;

create or replace function public.is_staff() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select role in ('director', 'educator') from public.profiles where id = auth.uid()), false)
$$;

create or replace function public.is_guardian_of(p_child uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.guardians where child_id = p_child and profile_id = auth.uid())
$$;

-- New auth user -> profile row
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, full_name)
  values (new.id, new.email, coalesce(new.raw_user_meta_data ->> 'full_name', ''));
  return new;
end $$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

create or replace function public.touch_updated_at() returns trigger
language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

create trigger requirements_touch before update on public.requirements
  for each row execute function public.touch_updated_at();

-- ---------------------------------------------------------------------------
-- Onboarding RPCs
-- ---------------------------------------------------------------------------
create or replace function public.create_centre(p_name text, p_full_name text)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_id uuid;
begin
  if auth.uid() is null then raise exception 'Not signed in'; end if;
  if (select centre_id from profiles where id = auth.uid()) is not null then
    raise exception 'You already belong to a centre';
  end if;
  insert into centres (name) values (p_name) returning id into v_id;
  update profiles set centre_id = v_id, role = 'director', full_name = p_full_name
  where id = auth.uid();
  return v_id;
end $$;

-- Staff code -> educator, family code -> parent.
create or replace function public.join_centre(p_code text, p_full_name text)
returns public.user_role language plpgsql security definer set search_path = public as $$
declare v_centre centres; v_role user_role;
begin
  if auth.uid() is null then raise exception 'Not signed in'; end if;
  if (select centre_id from profiles where id = auth.uid()) is not null then
    raise exception 'You already belong to a centre';
  end if;
  select * into v_centre from centres where staff_code = upper(trim(p_code));
  if found then v_role := 'educator';
  else
    select * into v_centre from centres where family_code = upper(trim(p_code));
    if found then v_role := 'parent'; else raise exception 'That code does not match a centre'; end if;
  end if;
  update profiles set centre_id = v_centre.id, role = v_role, full_name = p_full_name
  where id = auth.uid();
  return v_role;
end $$;

-- Director links a signed-up parent to a child by email.
create or replace function public.link_guardian(p_child uuid, p_email text, p_relationship text default 'Parent')
returns void language plpgsql security definer set search_path = public as $$
declare v_parent profiles;
begin
  if my_role() <> 'director' then raise exception 'Only the director can link families'; end if;
  if (select centre_id from children where id = p_child) is distinct from my_centre_id() then
    raise exception 'Child not found';
  end if;
  select * into v_parent from profiles
   where lower(email) = lower(trim(p_email)) and centre_id = my_centre_id() and role = 'parent';
  if not found then
    raise exception 'No parent with that email has joined this centre yet. Share the family code with them first.';
  end if;
  insert into guardians (child_id, profile_id, relationship)
  values (p_child, v_parent.id, p_relationship)
  on conflict do nothing;
end $$;

-- Loads a realistic sample room for demos. Director only.
create or replace function public.load_demo_data()
returns void language plpgsql security definer set search_path = public as $$
declare
  v_centre uuid := my_centre_id();
  v_me uuid := auth.uid();
  v_possums uuid; v_wombats uuid;
  v_leo uuid; v_ava uuid; v_oli uuid; v_ruby uuid;
begin
  if my_role() <> 'director' then raise exception 'Only the director can load demo data'; end if;

  insert into rooms (centre_id, name, age_group) values (v_centre, 'Possums', '2–3 years') returning id into v_possums;
  insert into rooms (centre_id, name, age_group) values (v_centre, 'Wombats', '3–5 years') returning id into v_wombats;

  insert into children (centre_id, room_id, first_name, last_name, date_of_birth, alerts, home_language, photo_consent) values
    (v_centre, v_possums, 'Leo',  'Nguyen',   current_date - 860,  '{Dairy free}', 'Vietnamese', true) returning id into v_leo;
  insert into children (centre_id, room_id, first_name, last_name, date_of_birth, alerts, photo_consent) values
    (v_centre, v_possums, 'Ava',  'Kaur',     current_date - 1010, '{Asthma action plan}', true) returning id into v_ava;
  insert into children (centre_id, room_id, first_name, last_name, date_of_birth, alerts, photo_consent) values
    (v_centre, v_possums, 'Oliver','Tran',    current_date - 800,  '{Peanut anaphylaxis – EpiPen}', false) returning id into v_oli;
  insert into children (centre_id, room_id, first_name, last_name, date_of_birth, alerts, photo_consent) values
    (v_centre, v_wombats, 'Ruby', 'Chen',     current_date - 1450, '{Sunscreen from home}', true) returning id into v_ruby;
  insert into children (centre_id, room_id, first_name, last_name, date_of_birth, alerts, home_language, photo_consent) values
    (v_centre, v_possums, 'Mia',  'Hassan',   current_date - 1060, '{}', 'Arabic', true),
    (v_centre, v_wombats, 'Noah', 'Petrovic', current_date - 1300, '{Halal}', 'English', true),
    (v_centre, v_wombats, 'Isla', 'Brown',    current_date - 1520, '{}', 'English', true),
    (v_centre, v_wombats, 'Jack', 'Wilson',   current_date - 1380, '{Egg allergy}', 'English', true);

  insert into requirements (centre_id, subject_type, child_id, kind, expires_on, notes) values
    (v_centre, 'child', v_oli, 'EpiPen', current_date - 6, 'Ask family for replacement'),
    (v_centre, 'child', v_oli, 'Anaphylaxis action plan', current_date + 120, ''),
    (v_centre, 'child', v_ava, 'Asthma action plan', current_date + 12, 'GP review booked?'),
    (v_centre, 'child', v_leo, 'Immunisation history statement', current_date + 45, ''),
    (v_centre, 'child', v_ruby, 'Immunisation history statement', current_date - 20, 'Overdue – chase family');

  insert into requirements (centre_id, subject_type, staff_id, kind, expires_on) values
    (v_centre, 'staff', v_me, 'First aid (HLTAID012)', current_date + 200),
    (v_centre, 'staff', v_me, 'Working with Children Check', current_date + 900);
  insert into requirements (centre_id, subject_type, staff_name, kind, expires_on, notes) values
    (v_centre, 'staff', 'Sarah Mitchell', 'First aid (HLTAID012)', current_date + 18, ''),
    (v_centre, 'staff', 'Sarah Mitchell', 'Working with Children Check', current_date + 400, ''),
    (v_centre, 'staff', 'James Lee', 'CPR refresher', current_date - 3, 'Annual refresher lapsed'),
    (v_centre, 'staff', 'James Lee', 'Child protection training', current_date + 260, ''),
    (v_centre, 'staff', 'Priya Sharma', 'Working with Children Check', current_date + 25, '');
  insert into requirements (centre_id, subject_type, kind, expires_on, notes) values
    (v_centre, 'centre', 'Emergency evacuation drill', current_date + 9, 'Quarterly'),
    (v_centre, 'centre', 'Fire extinguisher service', current_date + 150, ''),
    (v_centre, 'centre', 'Sun protection policy review', current_date - 30, 'Annual review overdue'),
    (v_centre, 'centre', 'Playground safety check', current_date + 2, 'Weekly');

  insert into logs (centre_id, child_id, author_id, category, title, parent_note, details, eylf_outcome, status, approved_by, approver_name, approved_at) values
    (v_centre, v_leo, v_me, 'learning', 'Built a tall block tower with Mia',
     'Leo built a block tower taller than himself and counted the blocks with Mia. When it toppled he laughed and started again.',
     '[{"label":"With","value":"Mia"},{"label":"Activity","value":"Block building"}]',
     'Outcome 4: Children are confident and involved learners', 'approved', v_me, (select full_name from profiles where id = v_me), now() - interval '3 hours'),
    (v_centre, v_ava, v_me, 'meal', 'Ate most of her lunch',
     'Ava ate most of her chicken and rice at lunch and finished a full cup of water.',
     '[{"label":"Amount","value":"Most"}]', null, 'approved', v_me, (select full_name from profiles where id = v_me), now() - interval '1 hour');
end $$;

-- ---------------------------------------------------------------------------
-- Row level security
-- ---------------------------------------------------------------------------
alter table public.centres      enable row level security;
alter table public.profiles     enable row level security;
alter table public.rooms        enable row level security;
alter table public.children     enable row level security;
alter table public.guardians    enable row level security;
alter table public.requirements enable row level security;
alter table public.memos        enable row level security;
alter table public.logs         enable row level security;

-- centres: members read; director updates
create policy "members read centre" on public.centres
  for select using (id = public.my_centre_id());
create policy "director updates centre" on public.centres
  for update using (id = public.my_centre_id() and public.my_role() = 'director');

-- profiles: read self + staff read everyone in centre; update self (not role/centre)
create policy "read own profile" on public.profiles
  for select using (id = auth.uid());
create policy "staff read centre profiles" on public.profiles
  for select using (centre_id = public.my_centre_id() and public.is_staff());
create policy "update own name" on public.profiles
  for update using (id = auth.uid())
  with check (
    id = auth.uid()
    and centre_id is not distinct from public.my_centre_id()
    and role is not distinct from public.my_role()
  );

-- rooms
create policy "members read rooms" on public.rooms
  for select using (centre_id = public.my_centre_id());
create policy "director manages rooms" on public.rooms
  for all using (centre_id = public.my_centre_id() and public.my_role() = 'director')
  with check (centre_id = public.my_centre_id() and public.my_role() = 'director');

-- children: staff read all in centre; parents read their own children
create policy "staff read children" on public.children
  for select using (centre_id = public.my_centre_id() and public.is_staff());
create policy "parents read own children" on public.children
  for select using (public.is_guardian_of(id));
create policy "director manages children" on public.children
  for all using (centre_id = public.my_centre_id() and public.my_role() = 'director')
  with check (centre_id = public.my_centre_id() and public.my_role() = 'director');

-- guardians: staff read; parents read own links; writes via link_guardian()
create policy "staff read guardians" on public.guardians
  for select using (public.is_staff() and exists (
    select 1 from public.children c where c.id = child_id and c.centre_id = public.my_centre_id()));
create policy "parents read own links" on public.guardians
  for select using (profile_id = auth.uid());
create policy "director removes guardians" on public.guardians
  for delete using (public.my_role() = 'director' and exists (
    select 1 from public.children c where c.id = child_id and c.centre_id = public.my_centre_id()));

-- requirements: staff only. Educators read; director writes.
create policy "staff read requirements" on public.requirements
  for select using (centre_id = public.my_centre_id() and public.is_staff());
create policy "director manages requirements" on public.requirements
  for all using (centre_id = public.my_centre_id() and public.my_role() = 'director')
  with check (centre_id = public.my_centre_id() and public.my_role() = 'director');

-- memos: staff only
create policy "staff read memos" on public.memos
  for select using (centre_id = public.my_centre_id() and public.is_staff());
create policy "staff write memos" on public.memos
  for insert with check (centre_id = public.my_centre_id() and public.is_staff() and educator_id = auth.uid());

-- logs: staff full access in centre; parents read approved logs for their children
create policy "staff read logs" on public.logs
  for select using (centre_id = public.my_centre_id() and public.is_staff());
create policy "staff create logs" on public.logs
  for insert with check (centre_id = public.my_centre_id() and public.is_staff() and author_id = auth.uid());
create policy "staff update logs" on public.logs
  for update using (centre_id = public.my_centre_id() and public.is_staff())
  with check (centre_id = public.my_centre_id() and public.is_staff());
create policy "staff delete draft logs" on public.logs
  for delete using (centre_id = public.my_centre_id() and public.is_staff() and status = 'draft');
create policy "parents read approved logs" on public.logs
  for select using (status = 'approved' and public.is_guardian_of(child_id));

grant execute on function public.create_centre(text, text) to authenticated;
grant execute on function public.join_centre(text, text) to authenticated;
grant execute on function public.link_guardian(uuid, text, text) to authenticated;
grant execute on function public.load_demo_data() to authenticated;
