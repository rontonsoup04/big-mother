export type Role = "director" | "educator" | "parent";
export type Status = "ok" | "due_soon" | "overdue";
export type Subject = "staff" | "child" | "centre";
export type LogCategory =
  | "meal" | "sleep" | "nappy" | "learning" | "wellbeing" | "incident" | "health" | "other";

export interface Profile {
  id: string;
  email: string;
  full_name: string;
  centre_id: string | null;
  role: Role | null;
}

export interface Centre {
  id: string;
  name: string;
  staff_code: string;
  family_code: string;
}

export interface Room {
  id: string;
  name: string;
  age_group: string;
}

export interface Child {
  id: string;
  room_id: string | null;
  first_name: string;
  last_name: string;
  date_of_birth: string | null;
  alerts: string[];
  home_language: string;
  photo_consent: boolean;
}

export interface RequirementRow {
  id: string;
  subject_type: Subject;
  subject_name: string;
  child_id: string | null;
  staff_id: string | null;
  kind: string;
  expires_on: string | null;
  completed_at: string | null;
  notes: string;
  status: Status;
}

export interface LogDetail {
  label: string;
  value: string;
}

export interface Log {
  id: string;
  child_id: string;
  category: LogCategory;
  title: string;
  parent_note: string;
  details: LogDetail[];
  eylf_outcome: string | null;
  flags: string[];
  status: "draft" | "approved";
  approver_name: string | null;
  approved_at: string | null;
  created_at: string;
}

export interface LogDraft {
  category: LogCategory;
  title: string;
  parent_note: string;
  details: LogDetail[];
  eylf_outcome: string | null;
  flags: string[];
}

export const CATEGORY_LABEL: Record<LogCategory, string> = {
  meal: "Meal",
  sleep: "Sleep",
  nappy: "Nappy / toilet",
  learning: "Learning",
  wellbeing: "Wellbeing",
  incident: "Incident",
  health: "Health",
  other: "Note",
};
