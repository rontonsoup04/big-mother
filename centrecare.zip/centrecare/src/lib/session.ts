import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import type { Centre, Profile, Role } from "@/lib/types";

export function isConfigured() {
  return Boolean(process.env.NEXT_PUBLIC_SUPABASE_URL && process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY);
}

/** Signed-in user with a centre. Redirects to login or onboarding otherwise. */
export async function requireMember(allowed?: Role[]) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: profile } = await supabase
    .from("profiles")
    .select("id, email, full_name, centre_id, role")
    .eq("id", user.id)
    .single<Profile>();

  if (!profile?.centre_id || !profile.role) redirect("/onboarding");
  if (allowed && !allowed.includes(profile.role)) redirect(profile.role === "parent" ? "/family" : "/dashboard");

  const { data: centre } = await supabase
    .from("centres")
    .select("id, name, staff_code, family_code")
    .eq("id", profile.centre_id)
    .single<Centre>();

  return { supabase, user, profile: profile as Profile & { role: Role; centre_id: string }, centre: centre! };
}

export function homeFor(role: Role) {
  return role === "parent" ? "/family" : "/dashboard";
}
