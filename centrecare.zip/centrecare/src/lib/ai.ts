import Anthropic from "@anthropic-ai/sdk";
import type { LogCategory, LogDraft } from "@/lib/types";

const CATEGORIES: LogCategory[] = ["meal", "sleep", "nappy", "learning", "wellbeing", "incident", "health", "other"];
const MODEL = process.env.ANTHROPIC_MODEL || "claude-sonnet-5-5";

export function aiEnabled() {
  return Boolean(process.env.ANTHROPIC_API_KEY);
}

interface ChildContext {
  firstName: string;
  age: string;
  alerts: string[];
}

async function askJSON<T>(prompt: string, maxTokens = 800): Promise<T> {
  const client = new Anthropic();
  const res = await client.messages.create({
    model: MODEL,
    max_tokens: maxTokens,
    messages: [{ role: "user", content: prompt }],
  });
  const text = res.content.map((b) => (b.type === "text" ? b.text : "")).join("");
  const json = text.slice(text.indexOf("{"), text.lastIndexOf("}") + 1);
  return JSON.parse(json) as T;
}

/** Step 1: tidy a dictated memo. Never adds facts. Flags words that may be misheard. */
export async function tidyTranscript(raw: string, child: ChildContext) {
  if (!aiEnabled()) return ruleTidy(raw);
  try {
    const out = await askJSON<{ clean: string; unsure: string[] }>(
      `You clean up a childcare educator's dictated memo about a child named ${child.firstName}.
Rules: fix punctuation, capitals and obvious speech-to-text errors; remove filler words (um, uh, like).
Keep every fact exactly. Do NOT add, infer, soften or exaggerate anything. Keep it short.
In "unsure", list words or phrases that look misheard or ambiguous (names, times, amounts). Empty list if none.
Return JSON only: {"clean": string, "unsure": string[]}

Memo: """${raw}"""`,
      400,
    );
    return { clean: out.clean || raw, unsure: Array.isArray(out.unsure) ? out.unsure : [] };
  } catch {
    return ruleTidy(raw);
  }
}

/** Step 2: turn an educator-confirmed transcript into a structured log draft. */
export async function draftLog(transcript: string, child: ChildContext): Promise<LogDraft> {
  if (!aiEnabled()) return ruleDraft(transcript, child);
  try {
    const out = await askJSON<LogDraft>(
      `You turn a reviewed childcare educator memo into one structured daily log for an Australian long day care centre.
Child: ${child.firstName}, age ${child.age || "unknown"}. Known alerts: ${child.alerts.join("; ") || "none"}.

STRICT RULES: use only facts in the memo. Never invent amounts, times, names, feelings or outcomes. If something is unclear, leave it out.
- category: one of ${CATEGORIES.join(", ")} (the main one).
- title: max 8 words.
- details: 1-4 short {label, value} pairs taken from the memo (e.g. Amount, Slept, With, Activity).
- eylf_outcome: only if the memo describes play or learning, the best-fitting EYLF V2.0 outcome (e.g. "Outcome 4: Children are confident and involved learners"); otherwise null.
- flags: short staff action items, e.g. "Complete incident report and notify family" for any injury, bite, fall or head knock; "Check against alert: <alert>" if food conflicts with a known alert; "Contact family" for illness signs. Empty list if none.
- parent_note: 1-3 warm, plain-English sentences to the family using the first name only. Specific, no jargon, no exaggeration.
Return JSON only: {"category": string, "title": string, "details": [{"label": string, "value": string}], "eylf_outcome": string|null, "flags": string[], "parent_note": string}

Memo: """${transcript}"""`,
    );
    return {
      category: CATEGORIES.includes(out.category) ? out.category : "other",
      title: out.title || "Note",
      details: Array.isArray(out.details) ? out.details.slice(0, 4) : [],
      eylf_outcome: out.eylf_outcome || null,
      flags: Array.isArray(out.flags) ? out.flags : [],
      parent_note: out.parent_note || transcript,
    };
  } catch {
    return ruleDraft(transcript, child);
  }
}

// ---------------------------------------------------------------------------
// Rule-based fallback so the app works without an AI key.
// ---------------------------------------------------------------------------
function ruleTidy(raw: string) {
  let clean = raw.replace(/\b(um+|uh+|erm)\b[,]?\s*/gi, "").replace(/\s+/g, " ").trim();
  clean = clean.replace(/(^|[.!?]\s+)([a-z])/g, (_, p, c) => p + c.toUpperCase());
  if (clean && !/[.!?]$/.test(clean)) clean += ".";
  const unsure = (raw.match(/\b\d{1,2}(:\d{2})?\b/g) || []).slice(0, 3).map((x) => `"${x}"`);
  return { clean, unsure };
}

function ruleDraft(text: string, child: ChildContext): LogDraft {
  const s = text.toLowerCase();
  const has = (words: string[]) => words.some((w) => s.includes(w));
  let category: LogCategory = "other";
  if (has(["fell", "fall", "bump", "bit ", "bite", "scratch", "hit his", "hit her", "cut", "bleed", "head"])) category = "incident";
  else if (has(["temperature", "fever", "vomit", "rash", "cough", "wheez", "puffer"])) category = "health";
  else if (has(["ate", "lunch", "morning tea", "afternoon tea", "snack", "bottle"])) category = "meal";
  else if (has(["slept", "sleep", "nap", "rest"])) category = "sleep";
  else if (has(["nappy", "toilet", "wee", "poo"])) category = "nappy";
  else if (has(["upset", "cried", "crying", "unsettled"])) category = "wellbeing";
  else if (has(["play", "built", "paint", "draw", "sand", "block", "read", "sing", "count", "puzzle"])) category = "learning";

  const flags: string[] = [];
  if (category === "incident") flags.push("Complete incident report and notify family");
  if (category === "health") flags.push("Contact family");

  return {
    category,
    title: `${category === "other" ? "Note" : category[0].toUpperCase() + category.slice(1)} update`,
    details: [],
    eylf_outcome: category === "learning" ? "Outcome 4: Children are confident and involved learners" : null,
    flags,
    parent_note: text.replace(/^(he|she|they)\b/i, child.firstName),
  };
}
