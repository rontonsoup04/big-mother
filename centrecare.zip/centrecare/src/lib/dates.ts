const TZ = "Australia/Sydney";

export function formatDate(d: string | null) {
  if (!d) return "No expiry";
  return new Date(d + (d.length === 10 ? "T00:00:00" : "")).toLocaleDateString("en-AU", {
    day: "numeric", month: "short", year: "numeric", timeZone: TZ,
  });
}

export function formatTime(ts: string) {
  return new Date(ts).toLocaleTimeString("en-AU", { hour: "numeric", minute: "2-digit", timeZone: TZ });
}

export function formatDay(ts: string) {
  return new Date(ts).toLocaleDateString("en-AU", { weekday: "long", day: "numeric", month: "long", timeZone: TZ });
}

export function daysUntil(d: string | null) {
  if (!d) return null;
  const today = new Date(new Date().toLocaleDateString("en-CA", { timeZone: TZ }) + "T00:00:00");
  const target = new Date(d + "T00:00:00");
  return Math.round((target.getTime() - today.getTime()) / 86_400_000);
}

export function relativeExpiry(d: string | null) {
  const n = daysUntil(d);
  if (n === null) return "Needs follow-up";
  if (n < 0) return `Expired ${-n} day${n === -1 ? "" : "s"} ago`;
  if (n === 0) return "Expires today";
  return `Expires in ${n} day${n === 1 ? "" : "s"}`;
}

export function ageFrom(dob: string | null) {
  if (!dob) return "";
  const b = new Date(dob + "T00:00:00");
  const now = new Date();
  let months = (now.getFullYear() - b.getFullYear()) * 12 + now.getMonth() - b.getMonth();
  if (now.getDate() < b.getDate()) months--;
  const y = Math.floor(months / 12), m = months % 12;
  return y > 0 ? `${y} yr${y > 1 ? "s" : ""} ${m} mo` : `${m} mo`;
}

/** Start of today in Sydney, as an ISO timestamp. */
export function startOfTodayISO() {
  const ymd = new Date().toLocaleDateString("en-CA", { timeZone: TZ });
  const offset = new Date().toLocaleString("en-US", { timeZone: TZ, timeZoneName: "longOffset" }).split("GMT")[1] || "+10:00";
  return new Date(`${ymd}T00:00:00${offset}`).toISOString();
}
