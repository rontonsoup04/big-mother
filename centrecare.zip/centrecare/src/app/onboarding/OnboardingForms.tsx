"use client";

import { useActionState } from "react";
import { createCentre, joinCentre, type FormState } from "./actions";

export default function OnboardingForms() {
  const [createState, createAction, creating] = useActionState<FormState, FormData>(createCentre, {});
  const [joinState, joinAction, joining] = useActionState<FormState, FormData>(joinCentre, {});

  return (
    <div className="mt-8 grid gap-4 md:grid-cols-2">
      <form action={createAction} className="card flex flex-col gap-4 p-5">
        <div>
          <h2 className="h2">I run a centre</h2>
          <p className="text-sm text-muted">You&apos;ll be the director and can invite staff and families.</p>
        </div>
        <div>
          <label className="label" htmlFor="c-name">Your name</label>
          <input id="c-name" name="name" required className="input" placeholder="Dana Smith" />
        </div>
        <div>
          <label className="label" htmlFor="c-centre">Centre name</label>
          <input id="c-centre" name="centre" required className="input" placeholder="Little Gumnuts Early Learning" />
        </div>
        {createState.error && <p className="text-sm font-bold text-over">{createState.error}</p>}
        <button className="btn mt-auto" disabled={creating}>{creating ? "Creating…" : "Create centre"}</button>
      </form>

      <form action={joinAction} className="card flex flex-col gap-4 p-5">
        <div>
          <h2 className="h2">I&apos;m joining a centre</h2>
          <p className="text-sm text-muted">Educators use the staff code. Families use the family code.</p>
        </div>
        <div>
          <label className="label" htmlFor="j-name">Your name</label>
          <input id="j-name" name="name" required className="input" placeholder="Sarah Mitchell" />
        </div>
        <div>
          <label className="label" htmlFor="j-code">Join code</label>
          <input id="j-code" name="code" required className="input uppercase tracking-widest" placeholder="A1B2C3" maxLength={6} />
        </div>
        {joinState.error && <p className="text-sm font-bold text-over">{joinState.error}</p>}
        <button className="btn mt-auto" disabled={joining}>{joining ? "Joining…" : "Join centre"}</button>
      </form>
    </div>
  );
}
