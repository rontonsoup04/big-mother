import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import OnboardingForms from "./OnboardingForms";

export default async function OnboardingPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  const { data: profile } = await supabase.from("profiles").select("centre_id, role").eq("id", user.id).single();
  if (profile?.centre_id) redirect(profile.role === "parent" ? "/family" : "/dashboard");

  return (
    <main className="mx-auto max-w-3xl px-4 py-12">
      <p className="text-sm font-bold uppercase tracking-widest text-accent">CentreCare</p>
      <h1 className="h1 mt-1">Set up your account</h1>
      <p className="mt-2 text-muted">Signed in as {user.email}. Create a new centre, or join one with a code from your director.</p>
      <OnboardingForms />
    </main>
  );
}
