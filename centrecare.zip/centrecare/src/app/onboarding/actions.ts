"use server";

import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export type FormState = { error?: string };

export async function createCentre(_: FormState, form: FormData): Promise<FormState> {
  const supabase = await createClient();
  const { error } = await supabase.rpc("create_centre", {
    p_name: String(form.get("centre") || "").trim(),
    p_full_name: String(form.get("name") || "").trim(),
  });
  if (error) return { error: error.message };
  redirect("/dashboard");
}

export async function joinCentre(_: FormState, form: FormData): Promise<FormState> {
  const supabase = await createClient();
  const { data, error } = await supabase.rpc("join_centre", {
    p_code: String(form.get("code") || ""),
    p_full_name: String(form.get("name") || "").trim(),
  });
  if (error) return { error: error.message };
  redirect(data === "parent" ? "/family" : "/dashboard");
}
