"use client";

import { useActionState } from "react";
import { linkGuardian } from "./actions";

export default function LinkGuardian({ childId }: { childId: string }) {
  const [state, action, pending] = useActionState(linkGuardian, {} as { error?: string; ok?: boolean });
  return (
    <form action={action} className="flex flex-col gap-2">
      <input type="hidden" name="child_id" value={childId} />
      <label className="label" htmlFor="g-email">Link a family member</label>
      <div className="flex flex-wrap gap-2">
        <input id="g-email" name="email" type="email" required className="input flex-1" placeholder="parent@email.com" />
        <select name="relationship" className="input !w-auto" aria-label="Relationship">
          <option>Parent</option><option>Guardian</option><option>Grandparent</option><option>Carer</option>
        </select>
        <button className="btn-ghost" disabled={pending}>{pending ? "Linking…" : "Link"}</button>
      </div>
      <p className="text-xs text-muted">They need to sign up and join with your family code first.</p>
      {state.error && <p className="text-sm font-bold text-over">{state.error}</p>}
      {state.ok && <p className="text-sm font-bold text-ok">Linked. They&apos;ll now see approved updates.</p>}
    </form>
  );
}
