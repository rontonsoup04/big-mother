"use client";

import { useEffect, useRef, useState, useTransition } from "react";
import { approveLog, createDraft, discardDraft, tidyMemo } from "./actions";
import { CATEGORY_LABEL, type Log } from "@/lib/types";

// Minimal typing for the browser speech API (not in TS DOM lib).
type SpeechRec = {
  lang: string; interimResults: boolean; continuous: boolean;
  onresult: (e: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void;
  onerror: () => void; onend: () => void; start: () => void; stop: () => void;
};
type SpeechCtor = new () => SpeechRec;

const STEPS = ["Memo", "Check transcript", "Review update"];

export default function MemoFlow({ childId, firstName }: { childId: string; firstName: string }) {
  const [step, setStep] = useState(1);
  const [raw, setRaw] = useState("");
  const [clean, setClean] = useState("");
  const [unsure, setUnsure] = useState<string[]>([]);
  const [confirmed, setConfirmed] = useState(false);
  const [draft, setDraft] = useState<Log | null>(null);
  const [error, setError] = useState("");
  const [pending, start] = useTransition();
  const [listening, setListening] = useState(false);
  const [speechOk, setSpeechOk] = useState(false);
  const recRef = useRef<SpeechRec | null>(null);

  useEffect(() => {
    const w = window as unknown as { SpeechRecognition?: SpeechCtor; webkitSpeechRecognition?: SpeechCtor };
    setSpeechOk(Boolean(w.SpeechRecognition || w.webkitSpeechRecognition));
    return () => recRef.current?.stop();
  }, []);

  function toggleMic() {
    if (recRef.current) { recRef.current.stop(); recRef.current = null; setListening(false); return; }
    const w = window as unknown as { SpeechRecognition?: SpeechCtor; webkitSpeechRecognition?: SpeechCtor };
    const Ctor = w.SpeechRecognition || w.webkitSpeechRecognition;
    if (!Ctor) return;
    const rec = new Ctor();
    rec.lang = "en-AU"; rec.interimResults = true; rec.continuous = true;
    const base = raw ? raw.trim() + " " : "";
    rec.onresult = (e) => {
      let text = "";
      for (let i = 0; i < e.results.length; i++) text += e.results[i][0].transcript;
      setRaw(base + text);
    };
    rec.onerror = () => { setError("The microphone isn't available. Type the memo or use your keyboard's dictation."); };
    rec.onend = () => { recRef.current = null; setListening(false); };
    rec.start(); recRef.current = rec; setListening(true); setError("");
  }

  function reset() {
    setStep(1); setRaw(""); setClean(""); setUnsure([]); setConfirmed(false); setDraft(null); setError("");
  }

  function toTranscript() {
    recRef.current?.stop();
    setError("");
    start(async () => {
      const res = await tidyMemo(childId, raw);
      if ("error" in res && res.error) { setError(res.error); return; }
      const r = res as { clean: string; unsure: string[] };
      setClean(r.clean); setUnsure(r.unsure); setConfirmed(false); setStep(2);
    });
  }

  function toDraft() {
    setError("");
    start(async () => {
      const res = await createDraft(childId, clean);
      if (res.error || !res.log) { setError(res.error || "Couldn't create the update. Try again."); return; }
      setDraft(res.log); setStep(3);
    });
  }

  return (
    <section className="card flex flex-col gap-4 p-5">
      <div className="flex items-center justify-between gap-3">
        <h2 className="h2">New memo for {firstName}</h2>
        {step > 1 && <button className="text-sm font-bold text-muted" onClick={reset}>Start again</button>}
      </div>
      <ol className="flex gap-2 text-xs font-bold">
        {STEPS.map((s, i) => (
          <li key={s} className={`flex-1 border-t-4 pt-1 ${i + 1 <= step ? "border-accent" : "border-line"} ${i + 1 === step ? "text-accent" : i + 1 < step ? "text-fg" : "text-muted"}`}>
            {i + 1}. {s}
          </li>
        ))}
      </ol>

      {step === 1 && (
        <>
          <div className="flex items-center gap-3">
            {speechOk && (
              <button type="button" onClick={toggleMic} aria-label={listening ? "Stop recording" : "Record voice memo"}
                className={`grid size-14 shrink-0 place-items-center rounded-full text-accent-ink ${listening ? "animate-pulse bg-over" : "bg-accent"}`}>
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="9" y="3" width="6" height="11" rx="3" /><path d="M5 11a7 7 0 0 0 14 0M12 18v3" /></svg>
              </button>
            )}
            <p className="text-sm text-muted">
              {listening ? "Listening… tap again to stop." : speechOk ? "Tap the mic and speak, or type below." : "Type below, or use your keyboard's microphone to dictate."}
            </p>
          </div>
          <label className="label" htmlFor="memo">Short memo</label>
          <textarea id="memo" className="input min-h-28" value={raw} onChange={(e) => setRaw(e.target.value)}
            placeholder={`e.g. ${firstName} ate about half the pasta, slept 12:30 to 2, played in the sandpit with Noah making cakes.`} />
          <p className="text-xs text-muted">You&apos;ll check the transcript before anything is created.</p>
          {error && <p className="text-sm font-bold text-over">{error}</p>}
          <div className="flex justify-end"><button className="btn" disabled={pending || raw.trim().length < 3} onClick={toTranscript}>{pending ? "Tidying…" : "Transcribe and check"}</button></div>
        </>
      )}

      {step === 2 && (
        <>
          <label className="label" htmlFor="clean">Transcript. Fix anything that&apos;s wrong.</label>
          <textarea id="clean" className="input min-h-28" value={clean} onChange={(e) => setClean(e.target.value)} />
          {unsure.length > 0 && (
            <p className="rounded-xl bg-due-soft p-3 text-sm"><b className="text-due">Please double-check:</b> {unsure.join(", ")}</p>
          )}
          <details className="text-sm text-muted"><summary className="cursor-pointer">What you said originally</summary><p className="mt-2 rounded-xl bg-sunk p-3">{raw}</p></details>
          <label className="flex items-start gap-3">
            <input type="checkbox" className="mt-1 size-5 accent-[var(--accent)]" checked={confirmed} onChange={(e) => setConfirmed(e.target.checked)} />
            <span>This transcript is accurate. Only these facts will be used in the update.</span>
          </label>
          {error && <p className="text-sm font-bold text-over">{error}</p>}
          <div className="flex justify-end gap-2">
            <button className="btn-ghost" onClick={() => setStep(1)}>Back</button>
            <button className="btn" disabled={!confirmed || pending || !clean.trim()} onClick={toDraft}>{pending ? "Writing…" : "Create update"}</button>
          </div>
        </>
      )}

      {step === 3 && draft && <DraftReview log={draft} childId={childId} onDone={reset} />}
    </section>
  );
}

export function DraftReview({ log, childId, onDone }: { log: Log; childId: string; onDone?: () => void }) {
  const [title, setTitle] = useState(log.title);
  const [note, setNote] = useState(log.parent_note);
  const [error, setError] = useState("");
  const [pending, start] = useTransition();

  return (
    <div className="flex flex-col gap-4">
      <div className="rounded-xl border border-line bg-sunk/40 p-4">
        <div className="flex flex-wrap items-center gap-2">
          <span className="chip">{CATEGORY_LABEL[log.category]}</span>
          {log.flags.map((f) => <span key={f} className="chip chip-over">{f}</span>)}
        </div>
        {log.details.length > 0 && (
          <dl className="mt-3 grid grid-cols-[auto_1fr] gap-x-4 gap-y-1 text-sm">
            {log.details.map((d, i) => <div key={i} className="contents"><dt className="text-muted">{d.label}</dt><dd>{d.value}</dd></div>)}
          </dl>
        )}
        {log.eylf_outcome && <p className="mt-3 border-l-2 border-accent pl-2 text-sm"><b className="block text-xs uppercase tracking-wider text-accent">EYLF link</b>{log.eylf_outcome}</p>}
      </div>
      <div>
        <label className="label" htmlFor={`t-${log.id}`}>Title</label>
        <input id={`t-${log.id}`} className="input" value={title} onChange={(e) => setTitle(e.target.value)} />
      </div>
      <div>
        <label className="label" htmlFor={`n-${log.id}`}>Note for the family</label>
        <textarea id={`n-${log.id}`} className="input min-h-24" value={note} onChange={(e) => setNote(e.target.value)} />
      </div>
      {error && <p className="text-sm font-bold text-over">{error}</p>}
      <div className="flex flex-wrap justify-end gap-2">
        <button className="btn-ghost" disabled={pending} onClick={() => start(async () => { await discardDraft(log.id, childId); onDone?.(); })}>Discard</button>
        <button className="btn" disabled={pending || !note.trim()} onClick={() => start(async () => {
          const res = await approveLog(log.id, childId, title, note);
          if (res.error) setError(res.error); else onDone?.();
        })}>{pending ? "Saving…" : "Approve and send to family"}</button>
      </div>
    </div>
  );
}
