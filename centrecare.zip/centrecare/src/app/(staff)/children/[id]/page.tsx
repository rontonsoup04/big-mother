import Link from "next/link";
import { notFound } from "next/navigation";
import LogCard from "@/components/LogCard";
import StatusChip from "@/components/StatusChip";
import { requireMember } from "@/lib/session";
import { ageFrom, formatDay, relativeExpiry } from "@/lib/dates";
import type { Child, Log, RequirementRow } from "@/lib/types";
import MemoFlow, { DraftReview } from "./MemoFlow";
import LinkGuardian from "./LinkGuardian";

export default async function ChildPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const { supabase, profile } = await requireMember(["director", "educator"]);

  const { data: child } = await supabase.from("children").select("*").eq("id", id).maybeSingle<Child>();
  if (!child) notFound();

  const [{ data: logs }, { data: reqs }, { data: guardians }, { data: room }] = await Promise.all([
    supabase.from("logs").select("*").eq("child_id", id).order("created_at", { ascending: false }).limit(30),
    supabase.from("requirement_status").select("*").eq("child_id", id),
    supabase.from("guardians").select("relationship, profiles(full_name, email)").eq("child_id", id),
    child.room_id ? supabase.from("rooms").select("name").eq("id", child.room_id).maybeSingle() : Promise.resolve({ data: null }),
  ]);

  const all = (logs || []) as Log[];
  const drafts = all.filter((l) => l.status === "draft");
  const approved = all.filter((l) => l.status === "approved");
  const byDay = approved.reduce<Record<string, Log[]>>((acc, l) => {
    const day = formatDay(l.approved_at || l.created_at);
    (acc[day] ||= []).push(l);
    return acc;
  }, {});

  return (
    <div className="flex flex-col gap-6">
      <Link href={child.room_id ? `/room?room=${child.room_id}` : "/room"} className="text-sm font-bold text-accent">← Back to room</Link>

      <header className="flex flex-wrap items-start gap-4">
        <span className="grid size-16 place-items-center rounded-full bg-accent-soft text-2xl font-bold text-accent">{child.first_name[0]}{child.last_name[0] || ""}</span>
        <div className="min-w-0 flex-1">
          <h1 className="h1">{child.first_name} {child.last_name}</h1>
          <p className="text-muted">{[ageFrom(child.date_of_birth), room?.name, child.home_language !== "English" && `Home language: ${child.home_language}`].filter(Boolean).join(" · ")}</p>
          <div className="mt-2 flex flex-wrap gap-1">
            {child.alerts.map((a) => <span key={a} className="chip chip-over">⚠ {a}</span>)}
            {!child.photo_consent && <span className="chip">No photo consent</span>}
          </div>
        </div>
      </header>

      <div className="grid gap-6 lg:grid-cols-[1.2fr_1fr]">
        <div className="flex min-w-0 flex-col gap-6">
          <MemoFlow childId={child.id} firstName={child.first_name} />

          {drafts.length > 0 && (
            <section className="flex flex-col gap-3">
              <h2 className="h2">Waiting for review ({drafts.length})</h2>
              {drafts.map((d) => <div key={d.id} className="card p-5"><DraftReview log={d} childId={child.id} /></div>)}
            </section>
          )}

          <section className="flex flex-col gap-3">
            <h2 className="h2">Sent to family</h2>
            {approved.length === 0 && <p className="card p-5 text-muted">No updates sent yet.</p>}
            {Object.entries(byDay).map(([day, items]) => (
              <div key={day} className="flex flex-col gap-2">
                <p className="text-sm font-bold text-muted">{day}</p>
                {items.map((l) => <LogCard key={l.id} log={l} />)}
              </div>
            ))}
          </section>
        </div>

        <aside className="flex min-w-0 flex-col gap-6">
          <section className="card p-5">
            <h2 className="h2 mb-3">Health and compliance</h2>
            {(reqs || []).length === 0 ? <p className="text-sm text-muted">Nothing tracked for {child.first_name}.</p> : (
              <ul className="flex flex-col gap-3">
                {((reqs || []) as RequirementRow[]).map((r) => (
                  <li key={r.id} className="flex items-center justify-between gap-3">
                    <div className="min-w-0"><p className="font-bold">{r.kind}</p><p className="text-sm text-muted">{relativeExpiry(r.expires_on)}</p></div>
                    <StatusChip status={r.status} />
                  </li>
                ))}
              </ul>
            )}
          </section>

          <section className="card flex flex-col gap-3 p-5">
            <h2 className="h2">Family</h2>
            {(guardians || []).length === 0 ? <p className="text-sm text-muted">No family members linked yet.</p> : (
              <ul className="flex flex-col gap-1">
                {(guardians || []).map((g, i) => {
                  const p = (Array.isArray(g.profiles) ? g.profiles[0] : g.profiles) as { full_name: string; email: string } | null;
                  return <li key={i}><b>{p?.full_name || p?.email}</b> <span className="text-sm text-muted">· {g.relationship}</span></li>;
                })}
              </ul>
            )}
            {profile.role === "director" && <LinkGuardian childId={child.id} />}
          </section>
        </aside>
      </div>
    </div>
  );
}
