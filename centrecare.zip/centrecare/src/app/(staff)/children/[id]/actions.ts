"use server";

import { revalidatePath } from "next/cache";
import { requireMember } from "@/lib/session";
import { draftLog, tidyTranscript } from "@/lib/ai";
import { ageFrom } from "@/lib/dates";
import type { Log } from "@/lib/types";

async function childContext(childId: string) {
  const { supabase, profile, centre } = await requireMember(["director", "educator"]);
  const { data: child, error } = await supabase
    .from("children").select("id, first_name, date_of_birth, alerts").eq("id", childId).single();
  if (error || !child) throw new Error("Child not found");
  return {
    supabase, profile, centre, child,
    ctx: { firstName: child.first_name, age: ageFrom(child.date_of_birth), alerts: child.alerts as string[] },
  };
}

export async function tidyMemo(childId: string, raw: string) {
  const text = raw.trim();
  if (text.length < 3) return { error: "Add a few words about what happened first." };
  const { ctx } = await childContext(childId);
  return tidyTranscript(text, ctx);
}

export async function createDraft(childId: string, transcript: string): Promise<{ log?: Log; error?: string }> {
  const text = transcript.trim();
  if (!text) return { error: "The transcript is empty." };
  const { supabase, profile, centre, ctx } = await childContext(childId);

  const { data: memo, error: memoErr } = await supabase.from("memos")
    .insert({ centre_id: centre.id, child_id: childId, educator_id: profile.id, transcript: text })
    .select("id").single();
  if (memoErr) return { error: memoErr.message };

  const draft = await draftLog(text, ctx);
  const { data: log, error } = await supabase.from("logs")
    .insert({ centre_id: centre.id, child_id: childId, memo_id: memo.id, author_id: profile.id, ...draft })
    .select("*").single();
  if (error) return { error: error.message };
  revalidatePath(`/children/${childId}`);
  return { log: log as Log };
}

export async function approveLog(logId: string, childId: string, title: string, parentNote: string) {
  const { supabase, profile } = await requireMember(["director", "educator"]);
  const { error } = await supabase.from("logs").update({
    title: title.trim() || "Update",
    parent_note: parentNote.trim(),
    status: "approved",
    approved_by: profile.id,
    approver_name: profile.full_name || profile.email,
    approved_at: new Date().toISOString(),
  }).eq("id", logId);
  revalidatePath(`/children/${childId}`);
  revalidatePath("/dashboard");
  revalidatePath("/room");
  return { error: error?.message };
}

export async function discardDraft(logId: string, childId: string) {
  const { supabase } = await requireMember(["director", "educator"]);
  await supabase.from("logs").delete().eq("id", logId).eq("status", "draft");
  revalidatePath(`/children/${childId}`);
}

export async function linkGuardian(_: { error?: string; ok?: boolean }, form: FormData) {
  const { supabase } = await requireMember(["director"]);
  const childId = String(form.get("child_id"));
  const { error } = await supabase.rpc("link_guardian", {
    p_child: childId,
    p_email: String(form.get("email") || ""),
    p_relationship: String(form.get("relationship") || "Parent"),
  });
  if (error) return { error: error.message };
  revalidatePath(`/children/${childId}`);
  return { ok: true };
}
