import Link from "next/link";
import StatusChip from "@/components/StatusChip";
import LogCard from "@/components/LogCard";
import { requireMember } from "@/lib/session";
import { formatDate, formatDay, relativeExpiry, startOfTodayISO } from "@/lib/dates";
import type { Child, Log, RequirementRow } from "@/lib/types";

export default async function DashboardPage() {
  const { supabase, profile } = await requireMember(["director", "educator"]);
  const today = startOfTodayISO();

  const [{ data: reqs }, { data: children }, { data: logs }] = await Promise.all([
    supabase.from("requirement_status").select("*").order("expires_on", { ascending: true, nullsFirst: true }),
    supabase.from("children").select("id, first_name, last_name, alerts, room_id").order("first_name"),
    supabase.from("logs").select("*").gte("created_at", today).order("created_at", { ascending: false }),
  ]);

  const rows = (reqs || []) as RequirementRow[];
  const kids = (children || []) as Child[];
  const todays = (logs || []) as Log[];

  const overdue = rows.filter((r) => r.status === "overdue");
  const due = rows.filter((r) => r.status === "due_soon");
  const score = rows.length ? Math.round((rows.filter((r) => r.status === "ok").length / rows.length) * 100) : 100;
  const attention = [...overdue, ...due].slice(0, 6);

  const drafts = todays.filter((l) => l.status === "draft");
  const approved = todays.filter((l) => l.status === "approved");
  const covered = new Set(approved.map((l) => l.child_id));
  const notYet = kids.filter((k) => !covered.has(k.id));
  const nameOf = (id: string) => kids.find((k) => k.id === id)?.first_name || "";

  return (
    <div className="flex flex-col gap-8">
      <div>
        <p className="text-sm text-muted">{formatDay(new Date().toISOString())}</p>
        <h1 className="h1">Good day, {profile.full_name.split(" ")[0] || "there"}</h1>
      </div>

      {kids.length === 0 && profile.role === "director" && (
        <div className="card flex flex-wrap items-center justify-between gap-3 p-5">
          <div>
            <h2 className="h2">Your centre is empty</h2>
            <p className="text-muted">Add rooms and children, or load a sample room to try things out.</p>
          </div>
          <Link href="/settings" className="btn">Set up centre</Link>
        </div>
      )}

      <section className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label="Compliance" value={`${score}%`} sub={`${rows.length} items tracked`} tone={score >= 90 ? "ok" : score >= 75 ? "due" : "over"} />
        <Stat label="Overdue" value={overdue.length} sub="Need action now" tone={overdue.length ? "over" : "ok"} />
        <Stat label="Due in 30 days" value={due.length} sub="Plan ahead" tone={due.length ? "due" : "ok"} />
        <Stat label="Families updated today" value={`${covered.size}/${kids.length}`} sub={`${drafts.length} draft${drafts.length === 1 ? "" : "s"} to review`} tone={notYet.length ? "due" : "ok"} />
      </section>

      <div className="grid gap-8 lg:grid-cols-[1.1fr_1fr]">
        <section className="min-w-0">
          <div className="mb-3 flex items-baseline justify-between">
            <h2 className="h2">Needs attention</h2>
            <Link href="/compliance" className="text-sm font-bold text-accent">All compliance →</Link>
          </div>
          {attention.length === 0 ? (
            <p className="card p-5 text-muted">Nothing overdue or due in the next 30 days.</p>
          ) : (
            <ul className="card divide-y divide-line">
              {attention.map((r) => (
                <li key={r.id} className="flex flex-wrap items-center gap-x-3 gap-y-1 p-4">
                  <div className="min-w-0 flex-1">
                    <p className="font-bold">{r.kind}</p>
                    <p className="text-sm text-muted">{r.subject_name} · {r.expires_on ? formatDate(r.expires_on) : "No date"}</p>
                  </div>
                  <span className={`text-sm font-bold ${r.status === "overdue" ? "text-over" : "text-due"}`}>{relativeExpiry(r.expires_on)}</span>
                  <StatusChip status={r.status} />
                </li>
              ))}
            </ul>
          )}
        </section>

        <section className="min-w-0">
          <div className="mb-3 flex items-baseline justify-between">
            <h2 className="h2">Today&apos;s updates</h2>
            <Link href="/room" className="text-sm font-bold text-accent">Add a memo →</Link>
          </div>
          {notYet.length > 0 && (
            <p className="mb-3 rounded-xl bg-due-soft p-3 text-sm">
              <b className="text-due">No update yet:</b> {notYet.slice(0, 8).map((k) => k.first_name).join(", ")}
              {notYet.length > 8 && ` and ${notYet.length - 8} more`}
            </p>
          )}
          <div className="flex flex-col gap-3">
            {todays.length === 0 && <p className="card p-5 text-muted">No logs yet today.</p>}
            {todays.slice(0, 5).map((l) => <LogCard key={l.id} log={l} childName={nameOf(l.child_id)} />)}
          </div>
        </section>
      </div>
    </div>
  );
}

function Stat({ label, value, sub, tone }: { label: string; value: string | number; sub: string; tone: "ok" | "due" | "over" }) {
  const color = { ok: "text-ok", due: "text-due", over: "text-over" }[tone];
  const bar = { ok: "bg-ok", due: "bg-due", over: "bg-over" }[tone];
  return (
    <div className="card relative overflow-hidden p-4">
      <span className={`absolute inset-y-0 left-0 w-1 ${bar}`} aria-hidden />
      <p className="label">{label}</p>
      <p className={`text-3xl font-bold tabular-nums ${color}`}>{value}</p>
      <p className="text-sm text-muted">{sub}</p>
    </div>
  );
}
