import Nav from "@/components/Nav";
import SetupNotice from "@/components/SetupNotice";
import { isConfigured, requireMember } from "@/lib/session";

export default async function StaffLayout({ children }: { children: React.ReactNode }) {
  if (!isConfigured()) return <SetupNotice />;
  const { profile, centre } = await requireMember(["director", "educator"]);
  return (
    <>
      <Nav centreName={centre.name} userName={profile.full_name || profile.email} role={profile.role} />
      <main className="mx-auto max-w-6xl px-4 pb-16 pt-6">{children}</main>
    </>
  );
}
