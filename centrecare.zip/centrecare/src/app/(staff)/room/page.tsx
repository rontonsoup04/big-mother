import Link from "next/link";
import { requireMember } from "@/lib/session";
import { ageFrom, startOfTodayISO } from "@/lib/dates";
import type { Child, Room } from "@/lib/types";

const HUES = ["#cfe6d9", "#f5ddb4", "#d8ddf2", "#f2d4cc", "#e3e8c6", "#cde5ec", "#eed7e6", "#e7dfcf"];

export default async function RoomPage({ searchParams }: { searchParams: Promise<{ room?: string }> }) {
  const { room } = await searchParams;
  const { supabase } = await requireMember(["director", "educator"]);

  const [{ data: rooms }, { data: children }, { data: logs }] = await Promise.all([
    supabase.from("rooms").select("id, name, age_group").order("name"),
    supabase.from("children").select("*").order("first_name"),
    supabase.from("logs").select("child_id, status").gte("created_at", startOfTodayISO()),
  ]);

  const allRooms = (rooms || []) as Room[];
  const active = room || allRooms[0]?.id || "all";
  const kids = ((children || []) as Child[]).filter((c) => active === "all" || c.room_id === active);
  const count = (id: string) => (logs || []).filter((l) => l.child_id === id && l.status === "approved").length;
  const drafts = (id: string) => (logs || []).filter((l) => l.child_id === id && l.status === "draft").length;
  const activeRoom = allRooms.find((r) => r.id === active);

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="h1">{activeRoom ? `${activeRoom.name} room` : "All children"}</h1>
        <p className="text-muted">{activeRoom?.age_group ? `${activeRoom.age_group} · ` : ""}Tap a child to add a memo.</p>
      </div>

      {allRooms.length > 1 && (
        <div className="flex flex-wrap gap-2">
          {allRooms.map((r) => (
            <Link key={r.id} href={`/room?room=${r.id}`}
              className={`rounded-lg px-3 py-1.5 text-sm font-bold ${active === r.id ? "bg-accent text-accent-ink" : "border border-line bg-surface text-muted"}`}>{r.name}</Link>
          ))}
          <Link href="/room?room=all" className={`rounded-lg px-3 py-1.5 text-sm font-bold ${active === "all" ? "bg-accent text-accent-ink" : "border border-line bg-surface text-muted"}`}>All</Link>
        </div>
      )}

      {kids.length === 0 ? (
        <p className="card p-6 text-muted">No children in this room yet. The director can add them under <Link href="/settings" className="font-bold text-accent">Centre</Link>.</p>
      ) : (
        <div className="grid grid-cols-[repeat(auto-fill,minmax(160px,1fr))] gap-3">
          {kids.map((k, i) => {
            const n = count(k.id), d = drafts(k.id);
            return (
              <Link key={k.id} href={`/children/${k.id}`} className="card flex min-h-40 flex-col gap-3 p-4 transition hover:border-accent active:scale-[.98]">
                <div className="flex items-center gap-3">
                  <span className="grid size-12 shrink-0 place-items-center rounded-full text-lg font-bold text-[#1b2621]" style={{ background: HUES[i % HUES.length] }}>
                    {k.first_name[0]}{k.last_name[0] || ""}
                  </span>
                  <div className="min-w-0">
                    <p className="truncate font-bold">{k.first_name}</p>
                    <p className="text-xs text-muted">{ageFrom(k.date_of_birth)}</p>
                  </div>
                </div>
                <div className="flex flex-wrap gap-1">{k.alerts.map((a) => <span key={a} className="chip chip-over">{a}</span>)}</div>
                <p className={`mt-auto text-sm font-bold ${n ? "text-ok" : "text-due"}`}>
                  {n ? `${n} update${n > 1 ? "s" : ""} sent` : "No update yet"}
                  {d > 0 && <span className="font-normal text-muted"> · {d} draft{d > 1 ? "s" : ""}</span>}
                </p>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
