import { requireMember } from "@/lib/session";
import { ChildForm, DemoButton, RoomForm } from "./Forms";
import { renameCentre } from "./actions";

export default async function SettingsPage() {
  const { supabase, profile, centre } = await requireMember(["director", "educator"]);
  const isDirector = profile.role === "director";
  const [{ data: rooms }, { data: staff }, { count }] = await Promise.all([
    supabase.from("rooms").select("id, name, age_group").order("name"),
    supabase.from("profiles").select("id, full_name, email, role").eq("centre_id", centre.id).order("role"),
    supabase.from("children").select("id", { count: "exact", head: true }),
  ]);

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="h1">Centre</h1>
        <p className="text-muted">{count ?? 0} children · {(rooms || []).length} rooms · {(staff || []).filter((s) => s.role !== "parent").length} staff on the app</p>
      </div>

      <section className="grid gap-3 sm:grid-cols-2">
        <div className="card p-5">
          <p className="label">Staff join code</p>
          <p className="font-mono text-3xl font-bold tracking-[.3em] text-accent">{centre.staff_code}</p>
          <p className="mt-1 text-sm text-muted">Give this to educators. They sign up, then enter it.</p>
        </div>
        {isDirector && (
          <div className="card p-5">
            <p className="label">Family join code</p>
            <p className="font-mono text-3xl font-bold tracking-[.3em]">{centre.family_code}</p>
            <p className="mt-1 text-sm text-muted">Give this to families. Then link them to their child on the child&apos;s page.</p>
          </div>
        )}
      </section>

      {isDirector && (
        <>
          <section className="card flex flex-col gap-4 p-5">
            <h2 className="h2">Centre details</h2>
            <form action={renameCentre} className="flex flex-wrap gap-2">
              <input name="name" defaultValue={centre.name} className="input flex-1" aria-label="Centre name" />
              <button className="btn-ghost">Save name</button>
            </form>
            <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl bg-sunk p-4">
              <p className="text-sm">Trying things out? Load two sample rooms with children, medical plans and staff checks.</p>
              <DemoButton />
            </div>
          </section>

          <section className="card flex flex-col gap-4 p-5">
            <h2 className="h2">Rooms</h2>
            {(rooms || []).length > 0 && (
              <ul className="flex flex-wrap gap-2">{(rooms || []).map((r) => <li key={r.id} className="chip !text-sm">{r.name}{r.age_group && ` · ${r.age_group}`}</li>)}</ul>
            )}
            <RoomForm />
          </section>

          <section className="card flex flex-col gap-4 p-5">
            <h2 className="h2">Add a child</h2>
            <ChildForm rooms={(rooms || []).map((r) => ({ id: r.id, name: r.name }))} />
          </section>
        </>
      )}

      <section className="card p-5">
        <h2 className="h2 mb-3">People on the app</h2>
        <ul className="divide-y divide-line">
          {(staff || []).map((s) => (
            <li key={s.id} className="flex items-center justify-between py-2">
              <span>{s.full_name || s.email}</span><span className="chip capitalize">{s.role}</span>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
