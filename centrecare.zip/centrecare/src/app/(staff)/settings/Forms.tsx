"use client";

import { useActionState, useEffect, useRef, useState, useTransition } from "react";
import { addChild, addRoom, loadDemo, type FormState } from "./actions";

export function DemoButton() {
  const [pending, start] = useTransition();
  const [state, setState] = useState<FormState>({});
  return (
    <div className="flex flex-col gap-2">
      <button className="btn-ghost" disabled={pending} onClick={() => start(async () => setState(await loadDemo()))}>
        {pending ? "Loading…" : "Load sample room"}
      </button>
      {state.ok && <p className="text-sm font-bold text-ok">Sample rooms, children and compliance items added.</p>}
      {state.error && <p className="text-sm font-bold text-over">{state.error}</p>}
    </div>
  );
}

function useResetOnOk(state: FormState) {
  const ref = useRef<HTMLFormElement>(null);
  useEffect(() => { if (state.ok) ref.current?.reset(); }, [state]);
  return ref;
}

export function RoomForm() {
  const [state, action, pending] = useActionState<FormState, FormData>(addRoom, {});
  const ref = useResetOnOk(state);
  return (
    <form ref={ref} action={action} className="flex flex-wrap items-end gap-2">
      <div className="min-w-40 flex-1"><label className="label" htmlFor="room-name">Room name</label><input id="room-name" name="name" className="input" placeholder="Possums" required /></div>
      <div className="min-w-32 flex-1"><label className="label" htmlFor="room-age">Age group</label><input id="room-age" name="age_group" className="input" placeholder="2–3 years" /></div>
      <button className="btn-ghost" disabled={pending}>Add room</button>
      {state.error && <p className="w-full text-sm font-bold text-over">{state.error}</p>}
    </form>
  );
}

export function ChildForm({ rooms }: { rooms: { id: string; name: string }[] }) {
  const [state, action, pending] = useActionState<FormState, FormData>(addChild, {});
  const ref = useResetOnOk(state);
  return (
    <form ref={ref} action={action} className="grid gap-3 sm:grid-cols-2">
      <div><label className="label" htmlFor="ch-first">First name</label><input id="ch-first" name="first_name" className="input" required /></div>
      <div><label className="label" htmlFor="ch-last">Last name</label><input id="ch-last" name="last_name" className="input" /></div>
      <div><label className="label" htmlFor="ch-dob">Date of birth</label><input id="ch-dob" name="date_of_birth" type="date" className="input" /></div>
      <div>
        <label className="label" htmlFor="ch-room">Room</label>
        <select id="ch-room" name="room_id" className="input">{rooms.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}<option value="">No room yet</option></select>
      </div>
      <div className="sm:col-span-2"><label className="label" htmlFor="ch-alerts">Alerts (comma separated)</label><input id="ch-alerts" name="alerts" className="input" placeholder="Peanut anaphylaxis – EpiPen, Dairy free" /></div>
      <div><label className="label" htmlFor="ch-lang">Home language</label><input id="ch-lang" name="home_language" className="input" defaultValue="English" /></div>
      <label className="flex items-center gap-2 self-end pb-2"><input type="checkbox" name="photo_consent" className="size-5 accent-[var(--accent)]" /> Photo consent given</label>
      {state.error && <p className="sm:col-span-2 text-sm font-bold text-over">{state.error}</p>}
      {state.ok && <p className="sm:col-span-2 text-sm font-bold text-ok">Child added.</p>}
      <div className="sm:col-span-2 flex justify-end"><button className="btn" disabled={pending}>{pending ? "Adding…" : "Add child"}</button></div>
    </form>
  );
}
