"use server";

import { revalidatePath } from "next/cache";
import { requireMember } from "@/lib/session";

export type FormState = { error?: string; ok?: boolean };

function refresh() {
  ["/settings", "/room", "/dashboard", "/compliance"].forEach((p) => revalidatePath(p));
}

export async function loadDemo(): Promise<FormState> {
  const { supabase } = await requireMember(["director"]);
  const { error } = await supabase.rpc("load_demo_data");
  if (error) return { error: error.message };
  refresh();
  return { ok: true };
}

export async function addRoom(_: FormState, form: FormData): Promise<FormState> {
  const { supabase, centre } = await requireMember(["director"]);
  const name = String(form.get("name") || "").trim();
  if (!name) return { error: "Give the room a name." };
  const { error } = await supabase.from("rooms").insert({ centre_id: centre.id, name, age_group: String(form.get("age_group") || "") });
  if (error) return { error: error.message };
  refresh();
  return { ok: true };
}

export async function addChild(_: FormState, form: FormData): Promise<FormState> {
  const { supabase, centre } = await requireMember(["director"]);
  const first = String(form.get("first_name") || "").trim();
  if (!first) return { error: "Enter the child's first name." };
  const alerts = String(form.get("alerts") || "").split(",").map((s) => s.trim()).filter(Boolean);
  const { error } = await supabase.from("children").insert({
    centre_id: centre.id,
    room_id: form.get("room_id") || null,
    first_name: first,
    last_name: String(form.get("last_name") || "").trim(),
    date_of_birth: form.get("date_of_birth") || null,
    alerts,
    home_language: String(form.get("home_language") || "English").trim() || "English",
    photo_consent: form.get("photo_consent") === "on",
  });
  if (error) return { error: error.message };
  refresh();
  return { ok: true };
}

export async function renameCentre(form: FormData) {
  const { supabase, centre } = await requireMember(["director"]);
  const name = String(form.get("name") || "").trim();
  if (name) await supabase.from("centres").update({ name }).eq("id", centre.id);
  refresh();
}
