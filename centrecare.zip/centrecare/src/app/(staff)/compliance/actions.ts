"use server";

import { revalidatePath } from "next/cache";
import { requireMember } from "@/lib/session";

export type FormState = { error?: string; ok?: boolean };

const COMMON_KINDS = [
  "First aid (HLTAID012)", "CPR refresher", "Anaphylaxis & asthma training", "Working with Children Check",
  "Child protection training", "Asthma action plan", "Anaphylaxis action plan", "EpiPen", "Medication",
  "Immunisation history statement", "Emergency evacuation drill", "Playground safety check",
  "Fire extinguisher service", "Policy review",
];
export async function commonKinds() { return COMMON_KINDS; }

export async function addRequirement(_: FormState, form: FormData): Promise<FormState> {
  const { supabase, centre } = await requireMember(["director"]);
  const subject = String(form.get("subject_type"));
  const kind = String(form.get("kind") || "").trim();
  if (!kind) return { error: "Say what the requirement is, for example 'First aid (HLTAID012)'." };

  const row: Record<string, unknown> = {
    centre_id: centre.id,
    subject_type: subject,
    kind,
    expires_on: form.get("expires_on") || null,
    notes: String(form.get("notes") || ""),
  };
  if (subject === "child") {
    row.child_id = form.get("child_id") || null;
    if (!row.child_id) return { error: "Choose which child this is for." };
  }
  if (subject === "staff") {
    const staff = String(form.get("staff") || "");
    if (!staff) return { error: "Choose or type the staff member's name." };
    if (staff.startsWith("id:")) row.staff_id = staff.slice(3);
    else row.staff_name = staff;
  }

  const { error } = await supabase.from("requirements").insert(row);
  if (error) return { error: error.message };
  revalidatePath("/compliance");
  revalidatePath("/dashboard");
  return { ok: true };
}

export async function renewRequirement(form: FormData) {
  const { supabase } = await requireMember(["director"]);
  await supabase.from("requirements")
    .update({ expires_on: form.get("expires_on") || null, completed_at: null })
    .eq("id", String(form.get("id")));
  revalidatePath("/compliance");
  revalidatePath("/dashboard");
}

export async function completeRequirement(form: FormData) {
  const { supabase } = await requireMember(["director"]);
  await supabase.from("requirements").update({ completed_at: new Date().toISOString() }).eq("id", String(form.get("id")));
  revalidatePath("/compliance");
  revalidatePath("/dashboard");
}

export async function deleteRequirement(form: FormData) {
  const { supabase } = await requireMember(["director"]);
  await supabase.from("requirements").delete().eq("id", String(form.get("id")));
  revalidatePath("/compliance");
  revalidatePath("/dashboard");
}
