import Link from "next/link";
import StatusChip from "@/components/StatusChip";
import { requireMember } from "@/lib/session";
import { formatDate, relativeExpiry } from "@/lib/dates";
import type { RequirementRow } from "@/lib/types";
import AddRequirement from "./AddRequirement";
import { commonKinds, completeRequirement, deleteRequirement, renewRequirement } from "./actions";

const SUBJECTS = [
  { key: "all", label: "Everything" },
  { key: "staff", label: "Staff" },
  { key: "child", label: "Children" },
  { key: "centre", label: "Centre" },
];
const STATUSES = [
  { key: "attention", label: "Needs attention" },
  { key: "all", label: "All" },
];

export default async function CompliancePage({ searchParams }: { searchParams: Promise<{ who?: string; show?: string; q?: string }> }) {
  const { who = "all", show = "attention", q = "" } = await searchParams;
  const { supabase, profile } = await requireMember(["director", "educator"]);
  const isDirector = profile.role === "director";

  let query = supabase.from("requirement_status").select("*").order("expires_on", { ascending: true, nullsFirst: true });
  if (who !== "all") query = query.eq("subject_type", who);
  const { data } = await query;
  let rows = (data || []) as RequirementRow[];
  const counts = {
    overdue: rows.filter((r) => r.status === "overdue").length,
    due: rows.filter((r) => r.status === "due_soon").length,
    ok: rows.filter((r) => r.status === "ok").length,
  };
  if (show === "attention") rows = rows.filter((r) => r.status !== "ok");
  if (q) rows = rows.filter((r) => `${r.kind} ${r.subject_name}`.toLowerCase().includes(q.toLowerCase()));
  rows.sort((a, b) => rank(a.status) - rank(b.status));

  const [{ data: kids }, { data: staff }] = isDirector
    ? await Promise.all([
        supabase.from("children").select("id, first_name, last_name").order("first_name"),
        supabase.from("profiles").select("id, full_name, email").in("role", ["director", "educator"]),
      ])
    : [{ data: [] }, { data: [] }];

  const href = (p: Record<string, string>) => `/compliance?${new URLSearchParams({ who, show, ...(q ? { q } : {}), ...p })}`;

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="h1">Compliance</h1>
          <p className="text-muted">Staff checks, children&apos;s medical plans and centre safety tasks in one place.</p>
        </div>
        <div className="flex gap-4 text-sm font-bold tabular-nums">
          <span className="text-over">{counts.overdue} overdue</span>
          <span className="text-due">{counts.due} due soon</span>
          <span className="text-ok">{counts.ok} up to date</span>
        </div>
      </div>

      {isDirector && (
        <AddRequirement
          kinds={await commonKinds()}
          childOptions={(kids || []).map((k) => ({ id: k.id, name: `${k.first_name} ${k.last_name}`.trim() }))}
          staff={(staff || []).map((s) => ({ id: s.id, name: s.full_name || s.email }))}
        />
      )}

      <div className="flex flex-wrap items-center gap-2">
        {SUBJECTS.map((s) => (
          <Link key={s.key} href={href({ who: s.key })}
            className={`rounded-lg px-3 py-1.5 text-sm font-bold ${who === s.key ? "bg-accent text-accent-ink" : "bg-surface text-muted border border-line"}`}>{s.label}</Link>
        ))}
        <span className="mx-1 h-6 w-px bg-line" />
        {STATUSES.map((s) => (
          <Link key={s.key} href={href({ show: s.key })}
            className={`rounded-lg px-3 py-1.5 text-sm font-bold ${show === s.key ? "bg-accent-soft text-accent" : "text-muted"}`}>{s.label}</Link>
        ))}
        <form className="ml-auto w-full sm:w-64" action="/compliance">
          <input type="hidden" name="who" value={who} /><input type="hidden" name="show" value={show} />
          <input name="q" defaultValue={q} className="input" placeholder="Search name or requirement" aria-label="Search" />
        </form>
      </div>

      {rows.length === 0 ? (
        <p className="card p-6 text-muted">
          {show === "attention" ? "Nothing needs attention here. " : "No requirements yet. "}
          {show === "attention" && <Link className="font-bold text-accent" href={href({ show: "all" })}>Show all</Link>}
        </p>
      ) : (
        <div className="card overflow-x-auto">
          <table className="w-full min-w-[640px] text-left">
            <thead className="border-b border-line text-xs uppercase tracking-wider text-muted">
              <tr><th className="p-3">Status</th><th className="p-3">Requirement</th><th className="p-3">For</th><th className="p-3">Date</th>{isDirector && <th className="p-3 text-right">Update</th>}</tr>
            </thead>
            <tbody className="divide-y divide-line">
              {rows.map((r) => (
                <tr key={r.id} className="align-top">
                  <td className="p-3"><StatusChip status={r.status} /></td>
                  <td className="p-3">
                    <p className="font-bold">{r.kind}</p>
                    {r.notes && <p className="text-sm text-muted">{r.notes}</p>}
                  </td>
                  <td className="p-3">
                    <p>{r.subject_name}</p>
                    <p className="text-xs capitalize text-muted">{r.subject_type}</p>
                  </td>
                  <td className="p-3 tabular-nums">
                    <p>{r.expires_on ? formatDate(r.expires_on) : "—"}</p>
                    <p className={`text-xs font-bold ${r.status === "overdue" ? "text-over" : r.status === "due_soon" ? "text-due" : "text-muted"}`}>
                      {r.completed_at && !r.expires_on ? "Done" : relativeExpiry(r.expires_on)}
                    </p>
                  </td>
                  {isDirector && (
                    <td className="p-3">
                      <div className="flex flex-wrap justify-end gap-2">
                        <form action={renewRequirement} className="flex gap-1">
                          <input type="hidden" name="id" value={r.id} />
                          <input type="date" name="expires_on" required className="input !w-36 !py-1 text-sm" aria-label={`New date for ${r.kind}`} />
                          <button className="btn-ghost btn-sm">Renew</button>
                        </form>
                        {!r.expires_on && !r.completed_at && (
                          <form action={completeRequirement}><input type="hidden" name="id" value={r.id} /><button className="btn-ghost btn-sm">Mark done</button></form>
                        )}
                        <form action={deleteRequirement}><input type="hidden" name="id" value={r.id} /><button className="btn-sm rounded-xl px-2 text-sm font-bold text-over">Remove</button></form>
                      </div>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function rank(s: string) { return s === "overdue" ? 0 : s === "due_soon" ? 1 : 2; }
