"use client";

import { useActionState, useEffect, useRef, useState } from "react";
import { addRequirement, type FormState } from "./actions";

interface Option { id: string; name: string }

export default function AddRequirement({ kinds, childOptions, staff }: { kinds: string[]; childOptions: Option[]; staff: Option[] }) {
  const [state, action, pending] = useActionState<FormState, FormData>(addRequirement, {});
  const [subject, setSubject] = useState<"staff" | "child" | "centre">("staff");
  const [open, setOpen] = useState(false);
  const [staffPick, setStaffPick] = useState(staff[0] ? `id:${staff[0].id}` : "other");
  const formRef = useRef<HTMLFormElement>(null);

  useEffect(() => { if (state.ok) formRef.current?.reset(); }, [state]);

  if (!open) return <button className="btn" onClick={() => setOpen(true)}>Add requirement</button>;

  return (
    <form ref={formRef} action={action} className="card grid w-full gap-4 p-5 md:grid-cols-2">
      <div className="md:col-span-2 flex items-center justify-between">
        <h2 className="h2">Add requirement</h2>
        <button type="button" className="btn-ghost btn-sm" onClick={() => setOpen(false)}>Close</button>
      </div>
      <fieldset className="md:col-span-2">
        <legend className="label">Who is it for?</legend>
        <div className="flex flex-wrap gap-2">
          {(["staff", "child", "centre"] as const).map((s) => (
            <label key={s} className={`cursor-pointer rounded-xl border px-4 py-2 font-bold capitalize ${subject === s ? "border-accent bg-accent-soft text-accent" : "border-line"}`}>
              <input type="radio" name="subject_type" value={s} checked={subject === s} onChange={() => setSubject(s)} className="sr-only" />
              {s === "centre" ? "The centre" : s}
            </label>
          ))}
        </div>
      </fieldset>

      {subject === "child" && (
        <div>
          <label className="label" htmlFor="child_id">Child</label>
          <select id="child_id" name="child_id" className="input" required defaultValue="">
            <option value="" disabled>Choose a child</option>
            {childOptions.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </div>
      )}
      {subject === "staff" && (
        <div className="flex flex-col gap-2">
          <label className="label" htmlFor="staff-pick">Staff member</label>
          <select id="staff-pick" className="input" value={staffPick} onChange={(e) => setStaffPick(e.target.value)}>
            {staff.map((s) => <option key={s.id} value={`id:${s.id}`}>{s.name}</option>)}
            <option value="other">Someone not on the app yet…</option>
          </select>
          {staffPick === "other" ? (
            <input name="staff" className="input" required placeholder="Their full name" aria-label="Staff member's name" />
          ) : (
            <input type="hidden" name="staff" value={staffPick} />
          )}
        </div>
      )}

      <div>
        <label className="label" htmlFor="kind">Requirement</label>
        <input id="kind" name="kind" list="kinds" className="input" required placeholder="e.g. First aid (HLTAID012)" />
        <datalist id="kinds">{kinds.map((k) => <option key={k} value={k} />)}</datalist>
      </div>
      <div>
        <label className="label" htmlFor="expires_on">Expires or due on</label>
        <input id="expires_on" name="expires_on" type="date" className="input" />
        <p className="mt-1 text-xs text-muted">Leave blank for a one-off task.</p>
      </div>
      <div className="md:col-span-2">
        <label className="label" htmlFor="notes">Notes</label>
        <input id="notes" name="notes" className="input" placeholder="Optional" />
      </div>
      {state.error && <p className="md:col-span-2 text-sm font-bold text-over">{state.error}</p>}
      {state.ok && <p className="md:col-span-2 text-sm font-bold text-ok">Added.</p>}
      <div className="md:col-span-2 flex justify-end">
        <button className="btn" disabled={pending}>{pending ? "Saving…" : "Save requirement"}</button>
      </div>
    </form>
  );
}
