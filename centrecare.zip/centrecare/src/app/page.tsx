export const dynamic = "force-dynamic";

import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { isConfigured } from "@/lib/session";
import SetupNotice from "@/components/SetupNotice";

export default async function Home() {
  if (!isConfigured()) return <SetupNotice />;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  const { data: profile } = await supabase.from("profiles").select("role, centre_id").eq("id", user.id).single();
  if (!profile?.centre_id) redirect("/onboarding");
  redirect(profile.role === "parent" ? "/family" : "/dashboard");
}
