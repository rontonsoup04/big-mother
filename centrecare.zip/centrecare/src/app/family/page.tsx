export const dynamic = "force-dynamic";

import LogCard from "@/components/LogCard";
import SetupNotice from "@/components/SetupNotice";
import { isConfigured, requireMember } from "@/lib/session";
import { formatDay } from "@/lib/dates";
import type { Child, Log } from "@/lib/types";

export default async function FamilyPage({ searchParams }: { searchParams: Promise<{ child?: string }> }) {
  if (!isConfigured()) return <SetupNotice />;
  const { child: picked } = await searchParams;
  const { supabase, profile, centre } = await requireMember(["parent"]);

  const { data: children } = await supabase.from("children").select("*").order("first_name");
  const kids = (children || []) as Child[];
  const active = kids.find((k) => k.id === picked) || kids[0];

  const { data: logs } = active
    ? await supabase.from("logs").select("*").eq("child_id", active.id).eq("status", "approved").order("approved_at", { ascending: false }).limit(50)
    : { data: [] };
  const byDay = ((logs || []) as Log[]).reduce<Record<string, Log[]>>((acc, l) => {
    (acc[formatDay(l.approved_at || l.created_at)] ||= []).push(l);
    return acc;
  }, {});

  return (
    <>
      <header className="border-b border-line">
        <div className="mx-auto flex max-w-2xl items-center justify-between gap-3 px-4 py-3">
          <div>
            <p className="text-xs font-bold uppercase tracking-widest text-accent">{centre.name}</p>
            <p className="font-bold">Hi {profile.full_name.split(" ")[0] || "there"}</p>
          </div>
          <form action="/auth/signout" method="post"><button className="btn-ghost btn-sm">Sign out</button></form>
        </div>
      </header>
      <main className="mx-auto flex max-w-2xl flex-col gap-6 px-4 pb-16 pt-6">
        {!active ? (
          <div className="card p-6">
            <h1 className="h2">You&apos;re in</h1>
            <p className="mt-1 text-muted">Your centre director needs to link you to your child. Once they do, updates from the educators will appear here.</p>
          </div>
        ) : (
          <>
            {kids.length > 1 && (
              <nav className="flex gap-2">
                {kids.map((k) => (
                  <a key={k.id} href={`/family?child=${k.id}`} className={`rounded-lg px-3 py-1.5 font-bold ${k.id === active.id ? "bg-accent text-accent-ink" : "border border-line bg-surface"}`}>{k.first_name}</a>
                ))}
              </nav>
            )}
            <h1 className="h1">{active.first_name}&apos;s day</h1>
            {Object.keys(byDay).length === 0 && <p className="card p-6 text-muted">No updates yet. Educators&apos; updates will show here during the day.</p>}
            {Object.entries(byDay).map(([day, items]) => (
              <section key={day} className="flex flex-col gap-2">
                <h2 className="text-sm font-bold text-muted">{day}</h2>
                {items.map((l) => <LogCard key={l.id} log={l} showFlags={false} />)}
              </section>
            ))}
          </>
        )}
      </main>
    </>
  );
}
