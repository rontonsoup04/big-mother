"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const LINKS = [
  { href: "/dashboard", label: "Today" },
  { href: "/room", label: "Room" },
  { href: "/compliance", label: "Compliance" },
  { href: "/settings", label: "Centre" },
];

export default function Nav({ centreName, userName, role }: { centreName: string; userName: string; role: string }) {
  const path = usePathname();
  return (
    <header className="sticky top-0 z-10 border-b border-line bg-bg/95 backdrop-blur">
      <div className="mx-auto flex max-w-6xl flex-wrap items-center gap-x-6 gap-y-2 px-4 py-3">
        <div className="min-w-0">
          <p className="text-xs font-bold uppercase tracking-widest text-accent">CentreCare</p>
          <p className="truncate font-bold">{centreName}</p>
        </div>
        <nav className="order-3 flex w-full gap-1 overflow-x-auto sm:order-none sm:w-auto">
          {LINKS.map((l) => {
            const active = path === l.href || (l.href === "/room" && path.startsWith("/children"));
            return (
              <Link key={l.href} href={l.href}
                className={`whitespace-nowrap rounded-lg px-3 py-2 text-sm font-bold ${active ? "bg-accent-soft text-accent" : "text-muted hover:text-fg"}`}>
                {l.label}
              </Link>
            );
          })}
        </nav>
        <div className="ml-auto flex items-center gap-3 text-sm">
          <span className="hidden text-muted sm:inline">{userName} · <span className="capitalize">{role}</span></span>
          <form action="/auth/signout" method="post">
            <button className="btn-ghost btn-sm">Sign out</button>
          </form>
        </div>
      </div>
    </header>
  );
}
