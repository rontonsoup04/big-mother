export default function SetupNotice() {
  return (
    <main className="mx-auto max-w-xl px-4 py-16">
      <h1 className="h1">CentreCare isn&apos;t connected to Supabase yet</h1>
      <p className="mt-3 text-muted">
        Add <code>NEXT_PUBLIC_SUPABASE_URL</code> and <code>NEXT_PUBLIC_SUPABASE_ANON_KEY</code> to
        <code> .env.local</code> (or your Vercel project settings), then restart. The README has the full steps.
      </p>
    </main>
  );
}
