import type { Status } from "@/lib/types";

const MAP: Record<Status, { cls: string; label: string }> = {
  ok: { cls: "chip chip-ok", label: "Up to date" },
  due_soon: { cls: "chip chip-due", label: "Due soon" },
  overdue: { cls: "chip chip-over", label: "Overdue" },
};

export default function StatusChip({ status }: { status: Status }) {
  const s = MAP[status];
  return <span className={s.cls}>{s.label}</span>;
}
