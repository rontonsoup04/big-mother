import { CATEGORY_LABEL, type Log } from "@/lib/types";
import { formatTime } from "@/lib/dates";

const TONE: Record<string, string> = {
  incident: "chip chip-over", health: "chip chip-over", wellbeing: "chip chip-due",
  learning: "chip chip-ok", meal: "chip chip-ok",
};

export default function LogCard({ log, childName, showFlags = true }: { log: Log; childName?: string; showFlags?: boolean }) {
  return (
    <article className="card grid grid-cols-[auto_1fr] gap-x-4 gap-y-1 p-4">
      <time className="pt-0.5 text-sm tabular-nums text-muted">{formatTime(log.approved_at || log.created_at)}</time>
      <div className="min-w-0">
        <div className="flex flex-wrap items-center gap-2">
          {childName && <b>{childName}</b>}
          <span className={TONE[log.category] || "chip"}>{CATEGORY_LABEL[log.category]}</span>
          <span className="font-bold">{log.title}</span>
        </div>
        <p className="mt-1">{log.parent_note}</p>
        {log.details?.length > 0 && (
          <dl className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-sm">
            {log.details.map((d, i) => (
              <div key={i} className="flex gap-1"><dt className="text-muted">{d.label}:</dt><dd>{d.value}</dd></div>
            ))}
          </dl>
        )}
        {log.eylf_outcome && <p className="mt-2 border-l-2 border-accent pl-2 text-sm text-muted">{log.eylf_outcome}</p>}
        {showFlags && log.flags?.length > 0 && (
          <div className="mt-2 flex flex-wrap gap-1">{log.flags.map((f) => <span key={f} className="chip chip-over">{f}</span>)}</div>
        )}
        <p className="mt-2 text-xs text-muted">
          {log.status === "approved"
            ? `Drafted with AI · reviewed by ${log.approver_name || "an educator"}`
            : "Draft · waiting for educator review"}
        </p>
      </div>
    </article>
  );
}
